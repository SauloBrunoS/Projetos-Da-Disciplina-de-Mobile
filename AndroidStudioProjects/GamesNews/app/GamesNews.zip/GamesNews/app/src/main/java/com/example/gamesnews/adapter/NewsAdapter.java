package com.example.gamesnews.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gamesnews.model.NewsResult;
import com.example.gamesnews.R;
import com.example.gamesnews.activity.WebViewActivity;
import com.squareup.picasso.Picasso;

import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {

    private List<NewsResult> newsResults;
    private Context context;

    public NewsAdapter(List<NewsResult> newsResults, Context context) {
        this.newsResults = newsResults;
        this.context = context;  // Recebe o contexto
    }


    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_news, parent, false);
        return new NewsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        NewsResult newsResult = newsResults.get(position);

        // Configura o título
        holder.tvNewsTitle.setText(newsResult.getTitle());

        // Configura a thumbnail da notícia
        Picasso.get().load(newsResult.getThumbnail()).placeholder(R.drawable.image_placeholder)
                .error(R.drawable.error_image_placeholder).into(holder.ivNewsThumbnail);

        // Configura o nome da fonte
        holder.tvSourceName.setText(newsResult.getSource().getName());

        // Configura o ícone da fonte
        Picasso.get().load(newsResult.getSource().getIcon()).into(holder.ivSourceIcon);

        ZonedDateTime now = ZonedDateTime.now();
        ZonedDateTime newsDate = newsResult.getDate();

        long daysAgo = ChronoUnit.DAYS.between(newsDate, now);
        long monthsAgo = ChronoUnit.MONTHS.between(newsDate, now);
        long yearsAgo = ChronoUnit.YEARS.between(newsDate, now);////

        String relativeDate;

        if (yearsAgo > 0) {
            if(yearsAgo == 1){
                relativeDate = "Postado há " + yearsAgo + " ano atrás";
            } else {
                relativeDate = "Postado há " + yearsAgo + " anos atrás";
            }
        } else if (monthsAgo > 0) {
            if(monthsAgo == 1){
                relativeDate = "Postado há " + monthsAgo + " mês atrás";
            } else {
                relativeDate = "Postado há " + monthsAgo + " meses atrás";
            }
        } else if (daysAgo > 0) {
            if (daysAgo == 1) {
                relativeDate = "Postado ontem";
            } else {
                relativeDate = "Postado há " + daysAgo + " dias atrás";
            }
        } else {
            long hoursAgo = ChronoUnit.HOURS.between(newsDate, now);
            if (hoursAgo == 0) {
                relativeDate = "Postado há menos de uma hora atrás";
            } else if (hoursAgo == 1) {
                relativeDate = "Postado há " + hoursAgo + " hora atrás";
            } else {
                relativeDate = "Postado há " + hoursAgo + " horas atrás";
            }
        }

        holder.tvNewsDate.setText(relativeDate);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, WebViewActivity.class);
            intent.putExtra("url", newsResult.getLink());  // Passa o link da notícia para a WebViewActivity
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return newsResults == null ? 0 : newsResults.size();
    }

    public class NewsViewHolder extends RecyclerView.ViewHolder {
        TextView tvNewsTitle, tvSourceName, tvNewsDate;
        ImageView ivNewsThumbnail, ivSourceIcon;

        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNewsTitle = itemView.findViewById(R.id.tv_news_title);
            ivNewsThumbnail = itemView.findViewById(R.id.iv_news_thumbnail);
            tvSourceName = itemView.findViewById(R.id.tv_source_name);
            ivSourceIcon = itemView.findViewById(R.id.iv_source_icon);
            tvNewsDate = itemView.findViewById(R.id.tv_news_date);
        }
    }
}

