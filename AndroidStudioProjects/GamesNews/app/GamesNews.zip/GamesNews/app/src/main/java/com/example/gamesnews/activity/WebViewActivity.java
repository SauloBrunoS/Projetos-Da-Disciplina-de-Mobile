package com.example.gamesnews.activity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

import com.example.gamesnews.R;

public class WebViewActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        webView = findViewById(R.id.wv_news_site);

        // Configurações da WebView
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);  // Ativa o JavaScript

        webView.setWebViewClient(new WebViewClient());  // Abre as páginas na WebView em vez do navegador

        // Pega a URL da Intent
        String url = getIntent().getStringExtra("url");

        // Carrega a URL na WebView
        if (url != null) {
            webView.loadUrl(url);
        }
    }
}
