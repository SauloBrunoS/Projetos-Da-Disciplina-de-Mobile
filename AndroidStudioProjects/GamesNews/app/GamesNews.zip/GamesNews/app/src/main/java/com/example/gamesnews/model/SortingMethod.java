package com.example.gamesnews.model;

public enum SortingMethod {
    DATE(1),
    RELEVANCE(0);

    private final int value;

    // Construtor do enum
    SortingMethod(int value) {
        this.value = value;
    }

    // Método para obter o valor associado ao enum
    public int getValue() {
        return value;
    }
}
