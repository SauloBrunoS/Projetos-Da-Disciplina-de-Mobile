package com.example.gamesnews.model;

import java.time.ZonedDateTime;

import javax.annotation.processing.Generated;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class NewsResult {

    @SerializedName("position")
    @Expose
    private long position;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("source")
    @Expose
    private Source source;
    @SerializedName("link")
    @Expose
    private String link;
    @SerializedName("thumbnail")
    @Expose
    private String thumbnail;
    @SerializedName("date")
    @Expose
    private ZonedDateTime date;

    public NewsResult() {
    }

    public NewsResult(long position, String title, Source source, String link, String thumbnail, ZonedDateTime date) {
        super();
        this.position = position;
        this.title = title;
        this.source = source;
        this.link = link;
        this.thumbnail = thumbnail;
        this.date = date;
    }

    public long getPosition() {
        return position;
    }

    public void setPosition(long position) {
        this.position = position;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Source getSource() {
        return source;
    }

    public void setSource(Source source) {
        this.source = source;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public ZonedDateTime getDate() {
        return date;
    }

    public void setDate(ZonedDateTime date) {
        this.date = date;
    }

}
