package com.example.gamesnews.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gamesnews.R;
import com.example.gamesnews.activity.MainActivity;
import com.example.gamesnews.adapter.NewsAdapter;
import com.example.gamesnews.model.NewsResult;
import com.example.gamesnews.retrofit.NewsCallback;
import com.example.gamesnews.retrofit.NewsFetcher;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class GameFragment extends Fragment {

    private static final String ARG_GAME_TITLE = "game_title";
    private String gameTitle;

    private RecyclerView recyclerView;
    private ProgressBar progressBar;

    private NewsAdapter newsAdapter;

    public static GameFragment newInstance(String gameTitle) {
        GameFragment fragment = new GameFragment();
        Bundle args = new Bundle();
        args.putString(ARG_GAME_TITLE, gameTitle);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_game, container, false);

        recyclerView = view.findViewById(R.id.rv_jogos_mais_populares);
        progressBar = view.findViewById(R.id.pb_jogos_mais_populares);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        if (getArguments() != null) {
            gameTitle = getArguments().getString(ARG_GAME_TITLE);
            fetchNews(gerarConsulta(gameTitle));
        }

        return view;
    }

    public static String gerarConsulta(String nomeDoJogo) {
        return String.format(
                "(\"%s\" OR \"atualizações de %s\" OR \"lançamento de %s\" OR \"mods de %s\" OR \"expansões de %s\" OR \"servidores de %s\") " +
                        "-\"agência\" -\"prefeitura\" -\"governo\"  -\"notícias políticas\" " +
                        "(site:jogos.com OR site:tecnologia.com OR \"notícias de jogos\")",
                nomeDoJogo, nomeDoJogo, nomeDoJogo, nomeDoJogo, nomeDoJogo, nomeDoJogo
        );
    }


    private void fetchNews(String query) {
        progressBar.setVisibility(View.VISIBLE);
        NewsFetcher newsFetcher = new NewsFetcher();
        String apiKey = "f38f24b84b5e00e51e9daf3ff7efe3812676d0940d06f83630f94abca914b083";

        newsFetcher.fetchNews(query, null, apiKey, null, null, null, null, new NewsCallback() {
            @Override
            public void onSuccess(List<NewsResult> newsResults) {
                progressBar.setVisibility(View.GONE);

                ExecutorService executorService = Executors.newFixedThreadPool(25);

                // Filtrar apenas resultados com URLs válidas e acessíveis
                new Thread(() -> {
                    List<NewsResult> validNewsResults = new ArrayList<>();
                    List<Future<Boolean>> futures = new ArrayList<>();

                    for (NewsResult result : newsResults) {
                        Callable<Boolean> task = () -> isAccessibleUrl(result.getLink());
                        futures.add(executorService.submit(task));
                    }

                    for (int i = 0; i < futures.size(); i++) {
                        try {
                            if (futures.get(i).get()) { // Se a URL for acessível, adicionar à lista
                                validNewsResults.add(newsResults.get(i));
                            }
                        } catch (Exception e) {
                            Log.e("MainActivity", "Erro ao verificar URL", e);
                        }
                    }
                    if (isAdded()) {
                        requireActivity().runOnUiThread(() -> {
                            // Configurar o adaptador apenas com as notícias válidas
                            newsAdapter = new NewsAdapter(validNewsResults, getContext());
                            recyclerView.setAdapter(newsAdapter);
                            executorService.shutdown();
                        });
                    }
                }).start();

            }

            // Método para verificar se o URL é acessível
            private boolean isAccessibleUrl(String urlString) {
                try {
                    URL url = new URL(urlString);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("HEAD"); // Usa o método HEAD para verificar a URL
                    connection.setConnectTimeout(1000); // Timeout de 5 segundos
                    connection.connect();

                    int responseCode = connection.getResponseCode();
                    return (responseCode >= 200 && responseCode < 400); // URLs com códigos de status 2xx e 3xx são válidas
                } catch (java.net.ConnectException e) {
                    return false; // Retorna falso para URLs com conexão recusada
                } catch (IOException e) {
                    return false;
                }
            }
            @Override
            public void onError(Throwable exception) {
                progressBar.setVisibility(View.GONE);
                // Tratar erro
                Log.e("GameFragment", "Erro ao realizar requisição a api do Google: ", exception);
            }
        });
    }
}

