package com.example.contador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tvContagem = findViewById(R.id.tv_contagem);
        Button btnAumentarContagem = findViewById(R.id.btn_aumentarContagem);

        btnAumentarContagem.setOnClickListener(new View.OnClickListener() {
            int cont = 0;
            @Override
            public void onClick(View v) {
                cont = cont + 1;
                tvContagem.setText(String.valueOf(cont));
            }
        });
    }
}